﻿using System;

class Program
{
    static void Main(string[] args)
    {
     Console.WriteLine("Введіть значення х: ");
     double x = Convert.ToDouble(Console.ReadLine());
     double y1 = Math.Round(Math.Cos(Math.Log(x)), 5);
     double y2 = Math.Round(Math.Abs(Math.Atan(x)), 5);
     Console.WriteLine("y = cos ln x = {0}", y1);
     Console.WriteLine("y = |arctg x| = {0}", y2);

     
    }

}

